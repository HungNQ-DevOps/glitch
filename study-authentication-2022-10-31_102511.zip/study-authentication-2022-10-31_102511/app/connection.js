// Do not change this file
require('dotenv').config();
const mongoose = require('mongoose');

async function main(callback) {
  const URI = process.env.MONGO_URI;
  const client = mongoose.connect(URI,
  {useNewUrlParser: true,
    useUnifiedTopology: true
  }, (err) => {
       if (err) {
          throw new Error('Unable to Connect to Database')
       } else {
         console.log("DB Connection is successful"); 
       }
  })
}
module.exports = main;